$x = Split-Path -Parent $MyInvocation.MyCommand.Definition

$appxs = Join-Path $x "\*.Appx"
Add-AppxPackage $appxs

$appxBundles = Join-Path $x "\*.AppxBundle"
Add-AppxPackage $appxBundles

pause