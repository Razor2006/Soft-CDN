get-appxpackage Microsoft.WindowsStore | remove-appxpackage
